Observações:

Para o código rodar, é necessária a instalação da biblioteca pyTelegramBotAPI através da Shell 
do compilador. Basta digitar "pip install pyTelegramBotAPI".

Caso preferir abrir o código em um compilador online, segue abaixo o link do mesmo no rep.lit:

https://replit.com/@NoriDos/CHATBOT-LUNARSIGHT#

 Documentação da biblioteca utilizada para a implementação:

(Https://Pytba.Readthedocs.Io/En/Latest/Index.Html)

Licença escolhida para o chatbot:

(Https://Opensource.Org/Licenses/Bsl-1.0)