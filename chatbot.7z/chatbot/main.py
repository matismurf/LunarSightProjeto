#Aqui, puxamos para o nosso código a biblioteca pyTelegramBotAPI recém instalada para poder ultilizar a mesma eventualmente, durante a implementação.

import telebot

#Antes de mais nada, é necessário abrir o aplicativo do Telegram e pesquisar por @BotFather - que é a API nativa responsável pelo gerenciamento dos chatbots do aplicativo - é lá que geramos a chave/token para realizar a conexão entre o código e o chatbot - basta criar uma variável (como por exemplo "key_api") e inserir a chave como podemos ver abaixo.

key_api = "5951217809:AAFSF4ByX3_Nu0j027989UMuufuQIjZfW1c"

bot = telebot.TeleBot(key_api)

#Abaixo, criamos um decorator para dar uma nova funcionalidade para a próxima linha - ela diz quando a função (por exemplo, a função "opção1" será executada.

@bot.message_handler(commands=["opcao1"])

#Essa função abaixo vai dizer o que irá acontecer quando o usuário interagir com determinado "botão". Como é possível visualizar, ela se refere a "opção1" - ou seja, ela irá responder a interação com a mensagem a seguir:

def opcao1(mensagem): bot.reply_to(mensagem,
                                   "Você pode apoiar a gente comprando nossos produtos e acompanhando nossas lives na twitch.")


@bot.message_handler(commands=["opcao2"])
def opcao2(mensagem): bot.reply_to(mensagem,
                                   "Fazemos lives de segunda a sexta no site roxinho e jogamos na faculdade TAL aos sábados.")


@bot.message_handler(commands=["opcao3"])
def opcao3(mensagem): bot.reply_to(mensagem,
                                   "Poxa, que legal! envie um email para LunarsightOFICIAL@gmail.com que entraremos em contato.")


@bot.message_handler(commands=["opcao4"])
def opcao4(mensagem): bot.reply_to(mensagem,
                                   "Nosso time é especialista nesses jogos: Valorant, Overwatch, Dota e CSGO!")


@bot.message_handler(commands=["opcao5"])
def opcao5(mensagem): bot.reply_to(mensagem, "Valeu pelo contato! tchau tchauu")

#Essa função funciona da seguinte forma: ela verifica se o usuário nos enviou alguma mensagem - e por padrão, caso ela não reconheça a palavra/interação, irá enviar para o usuário uma mensagem genérica contendo as opções disponíveis para interação.

def verificar(mensagem):
    return True

#O bot verificou a mensagem e ele reconheceu a interação? caso negativo, ele responderá de volta o usuário com a mensagem a seguir.

@bot.message_handler(func=verificar)
def responder(mensagem):
    texto = """
  Opa, bão? Aqui quem fala é a assistente virtual da Lunarsight!! Escolha uma opção abaixo para prosseguir com o atendimento:

        /opcao1 Como apoiar o time?
        /opcao2 Onde acompanhar o time?
        /opcao3 Quero o contato de vocês!
        /opcao4 Qual a especialidade do time?
        /opcao5 encerra o atendimento.

        Não envie outro tipo de mensagem! não irá funcionar."""
    bot.reply_to(mensagem, texto)

# Essa função é usada para começar um loop de recebimento de mensagens em um chatbot sem parar, fazendo com que o bot fique "online" e responda as mensagens do usuário em tempo real!

bot.polling()